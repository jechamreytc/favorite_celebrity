import 'package:fav_celeb/third_page.dart';
import 'package:flutter/material.dart';

class SecondPage extends StatelessWidget {
  const SecondPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Second Page"),
        leading: Icon(Icons.anchor),
        centerTitle: true,
        backgroundColor: Colors.blue,
      ),
      body: Center(
        child: ListView(
          children: [
            Column(
              children: [
                SizedBox(
                  height: 20.0,
                ),
                Image.asset(
                  'assets/images/jacksparrow.jpg',
                  height: 200,
                  width: 200,
                ),
                const Padding(
                  padding: EdgeInsets.all(30.0),
                  child: Column(
                    children: [
                      Text(
                        "In the 2000s, Depp became one of the most commercially successful film stars by playing Captain Jack Sparrow in the Walt Disney swashbuckler film series Pirates of the Caribbean (2003–2017). He also received acclaim for Chocolat (2000), Finding Neverland (2004) and Public Enemies (2009), and continued his commercially successful collaboration with Burton with the films Charlie and the Chocolate Factory (2005), Corpse Bride (2005), and Sweeney Todd: The Demon Barber of Fleet Street (2007). His other commercially successful films included From Hell (2001), Once Upon a Time in Mexico (2003), and Secret Window (2004).",
                        textAlign: TextAlign.justify,
                      ),
                      SizedBox(
                        height: 15.0,
                      ),
                      Text(
                        "In 2012, Depp was one of the world's biggest film stars, and was listed by the Guinness World Records as the world's highest-paid actor, with earnings of US 75 million in a year.During the 2010s, Depp began producing films through his company Infinitum Nihil. He also starred in Alice in Wonderland (2010), and received acclaim for Black Mass (2015). He formed the rock supergroup Hollywood Vampires with Alice Cooper and Joe Perry, before starring as Gellert Grindelwald in the Wizarding World films Fantastic Beasts and Where to Find Them (2016) and Fantastic Beasts: The Crimes of Grindelwald (2018).",
                        textAlign: TextAlign.justify,
                      ),
                    ],
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: Text("Home"),
                      style: ElevatedButton.styleFrom(
                        foregroundColor: Colors.white,
                        backgroundColor: Colors.blue,
                      ),
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) {
                              return ThirdPage();
                            },
                          ),
                        );
                      },
                      child: Text("Next Page"),
                      style: ElevatedButton.styleFrom(
                        foregroundColor: Colors.white,
                        backgroundColor: Colors.blue,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
