import 'package:fav_celeb/fourth_page.dart';
import 'package:flutter/material.dart';

class ThirdPage extends StatelessWidget {
  const ThirdPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Icon(Icons.anchor),
        title: Text("Third Page"),
        centerTitle: true,
        backgroundColor: Colors.blue,
      ),
      body: Center(
        child: ListView(
          children: [
            Column(
              children: [
                SizedBox(
                  height: 30,
                ),
                Image.asset(
                  'assets/images/depp2003.jpg',
                  height: 200,
                  width: 200,
                ),
                SizedBox(
                  height: 20,
                ),
                Padding(
                  padding: const EdgeInsets.all(30.0),
                  child: Text(
                    "Depp was named People's Sexiest Man Alive in 2003, an accolade he received again in 2009. Between 1998 and 2012, Depp was in a relationship with the French singer Vanessa Paradis, with whom he had two children, including the actress Lily-Rose Depp. From 2015 to 2017, Depp was married to the actress Amber Heard. Their divorce drew media attention, as both alleged abuse against each other and both engaged in highly publicized defamation cases.",
                    textAlign: TextAlign.justify,
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                Text(
                  "Early Life",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Padding(
                  padding: const EdgeInsets.all(30.0),
                  child: Text(
                    "Depp was born on June 9, 1963, in Owensboro, Kentucky, the youngest of four children of waitress Betty Sue Depp (née Wells; later Palmer) and civil engineer John Christopher Depp. Depp's family moved frequently during his childhood, eventually settling in Miramar, Florida, in 1970. His parents divorced in 1978 when he was 15, and his mother later married Robert Palmer, whom Depp has called 'an inspiration' .",
                    textAlign: TextAlign.justify,
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: Text("Previous Page"),
                      style: ElevatedButton.styleFrom(
                        foregroundColor: Colors.white,
                        backgroundColor: Colors.blue,
                      ),
                    ),
                    SizedBox(
                      width: 15,
                    ),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) {
                              return FourthPage();
                            },
                          ),
                        );
                      },
                      child: Text("Next Page"),
                      style: ElevatedButton.styleFrom(
                        foregroundColor: Colors.white,
                        backgroundColor: Colors.blue,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
