import 'package:fav_celeb/second_page.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Home Page",
        ),
        centerTitle: true,
        backgroundColor: Colors.blue,
      ),
      body: Center(
        child: ListView(
          children: [
            Column(
              children: [
                SizedBox(
                  height: 20,
                ),
                const Text(
                  "Johnny Depp",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Image.asset(
                  'assets/images/johnny depp.jpg',
                  height: 200,
                  width: 200,
                ),
                Container(
                  child: const Padding(
                    padding: EdgeInsets.all(30.0),
                    child: Column(
                      children: [
                        Text(
                          "John Christopher Depp II (born June 9, 1963) is an American actor and musician. He is the recipient of multiple accolades, including a Golden Globe Award and a Screen Actors Guild Award, and has been nominated for three Academy Awards and two BAFTA awards. His films have grossed over 8 billion worldwide, making him one of Hollywood's most bankable stars.",
                          textAlign: TextAlign.justify,
                        ),
                        SizedBox(
                          height: 15.0,
                        ),
                        Text(
                          "Born in Kentucky, Depp aspired to be a musician, and was a member of several rock bands. He moved to Los Angeles at age 20, where he was introduced to actor Nicolas Cage, who advised him to pursue acting. Depp made his feature film debut in the horror film A Nightmare on Elm Street (1984) and appeared in Platoon (1986), before rising to prominence as a teen idol on the television series 21 Jump Street (1987–1990). In the 1990s, Depp acted mostly in independent films with auteur directors, often playing eccentric characters. These included Cry-Baby (1990), What's Eating Gilbert Grape (1993), Benny and Joon (1993), Dead Man (1995), Donnie Brasco (1997), Fear and Loathing in Las Vegas (1998), and The Ninth Gate (1999). Depp also began his longtime collaboration with the director Tim Burton, portraying the leads in the films Edward Scissorhands (1990), Ed Wood (1994), and Sleepy Hollow (1999).",
                          textAlign: TextAlign.justify,
                        ),
                      ],
                    ),
                  ),
                ),
                ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) {
                          return SecondPage();
                        },
                      ),
                    );
                  },
                  child: Text("Next Page"),
                  style: ElevatedButton.styleFrom(
                    foregroundColor: Colors.white,
                    backgroundColor: Colors.blue,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
