import 'package:flutter/material.dart';

class FifthPage extends StatelessWidget {
  const FifthPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Icon(Icons.anchor),
        title: Text("Last Page"),
        centerTitle: true,
        backgroundColor: Colors.blue,
      ),
      body: Center(
          child: ListView(
        children: [
          Column(
            children: [
              SizedBox(
                height: 20.0,
              ),
              Image.asset(
                'assets/images/last.jpg',
                height: 200,
                width: 200,
              ),
              SizedBox(
                height: 20.0,
              ),
              Padding(
                padding: const EdgeInsets.all(30.0),
                child: Text(
                  "Makes sense in terms of coming from Kentucky, which is rife with Cherokee and Creek Indian .Depp's claims came under scrutiny when Indian Country Today wrote that Depp had never inquired about his heritage or been recognized as a member of the Cherokee Nation.[25] This led to criticism of Depp by the Native American community, as Depp has no documented Native ancestry,[25] and Native community leaders consider him a non-Indian and a pretendian.Depp's choice to portray Tonto, a Native American character, in The Lone Ranger was criticized, along with his choice to name his rock band 'Tonto's Giant Nuts'. During the promotion for The Lone Ranger, Depp was formally adopted as an honorary son by LaDonna Harris, a member of the Comanche Nation, making him an honorary member of her family but not a member of any tribe. Depp's Comanche name given at the adoption was 'Mah Woo May', which means shape shifter.Critical response to his claims from the Native community increased after this, including satirical portrayals of Depp by Native comedians. An ad featuring Depp and Native American imagery, by Dior for the fragrance 'Sauvage', was pulled in 2019 after being accused of cultural appropriation and racism.",
                  textAlign: TextAlign.justify,
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: Text("Previous Page"),
                    style: ElevatedButton.styleFrom(
                      foregroundColor: Colors.white,
                      backgroundColor: Colors.blue,
                    ),
                  ),
                  SizedBox(
                    width: 20,
                  ),
                  ElevatedButton(
                    onPressed: () {
                      showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return AlertDialog(
                            title: Row(
                              children: [
                                Text("About Page"),
                                SizedBox(
                                  width: 150.0,
                                ),
                                Icon(
                                  Icons.favorite,
                                  color: Colors.red,
                                ),
                              ],
                            ),
                            content: Text(
                              "The page is about Johnny Depp's history and current situation. The reference for this page is from wikipedia.org. \n \n The developer of this page is Jecham Rey T. Cabusog, a second-year BSIT student who wishes to graduate.",
                              textAlign: TextAlign.justify,
                            ),
                            actions: [
                              ElevatedButton(
                                onPressed: () {
                                  Navigator.pop(context);
                                },
                                child: Text("Close"),
                              ),
                            ],
                          );
                        },
                      );
                    },
                    child: Icon(Icons.warning),
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue,
                        foregroundColor: Colors.white),
                  ),
                ],
              ),
            ],
          ),
        ],
      )),
    );
  }
}
