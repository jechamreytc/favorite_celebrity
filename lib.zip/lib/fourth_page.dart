import 'package:fav_celeb/fifth_page.dart';
import 'package:flutter/material.dart';

class FourthPage extends StatelessWidget {
  const FourthPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Icon(Icons.anchor),
        title: Text("Fourth Page"),
        backgroundColor: Colors.blue,
        centerTitle: true,
      ),
      body: Center(
        child: ListView(
          children: [
            Column(
              children: [
                SizedBox(
                  height: 10.0,
                ),
                Image.asset(
                  "assets/images/guitar.jpg",
                  height: 200,
                  width: 200,
                ),
                SizedBox(
                  height: 15.0,
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    left: 30.0,
                    right: 30.0,
                  ),
                  child: Column(
                    children: [
                      Text(
                        "Depp's mother gave him a guitar when he was 12, and he began playing in various bands. He dropped out of Miramar High School at 16 in 1979 to become a rock musician. He attempted to go back to school two weeks later, but the principal told him to follow his dream of being a musician. In 1980, Depp began playing in a band called The Kids. After modest local success in Florida, the band moved to Los Angeles in pursuit of a record deal, changing its name to Six Gun Method. In addition to the band, Depp worked a variety of odd jobs, such as in telemarketing. In December 1983, Depp married makeup artist Lori Anne Allison,the sister of his band's bassist and singer. The Kids split up before signing a record deal in 1984, and Depp began collaborating with the band Rock City Angels.He co-wrote their song 'Mary', which appeared on their debut Geffen Records album Young Man's Blues.Depp and Allison divorced in 1985.",
                        textAlign: TextAlign.justify,
                      ),
                      SizedBox(
                        height: 15,
                      ),
                      Text(
                        "Depp is of primarily English descent, with some French, German, and Irish ancestry. His surname comes from a French Huguenot immigrant, Pierre Dieppe, who settled in Virginia around 1700. He is also a descendant of Elizabeth Key Grinstead, one of the first women of African American ancestry in the North American colonies to sue for her freedom and win. In interviews in 2002 and 2011, Depp claimed to have Native American ancestry, saying: 'I guess I have some Native American somewhere down the line. My great-grandmother was quite a bit of Native American. She grew up Cherokee or maybe Creek Indian'.",
                        textAlign: TextAlign.justify,
                      )
                    ],
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: Text("Previous Page"),
                      style: ElevatedButton.styleFrom(
                        foregroundColor: Colors.white,
                        backgroundColor: Colors.blue,
                      ),
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) {
                              return FifthPage();
                            },
                          ),
                        );
                      },
                      child: Text("Next Page"),
                      style: ElevatedButton.styleFrom(
                        foregroundColor: Colors.white,
                        backgroundColor: Colors.blue,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
